<footer class="container-fluid">
	<div class="row">
		<ul class="col-sm-5 col-xs-12 list-inline text-right">
			<li><a href="index.php">Iniciar busqueda</a></li>
			<li><a href="#">Quienes somos</a></li>
			<li><a href="#">Publica tu tienda</a></li>
		</ul>
		<ul class="iconos-sociales col-sm-3 col-xs-12 pull-right list-inline">
			<li id="icon_facebook"><a href="#facebook"></a></li>
			<li id="icon_twitter"><a href="#twitter"></a></li>
		</ul>		
	</div>
</footer>