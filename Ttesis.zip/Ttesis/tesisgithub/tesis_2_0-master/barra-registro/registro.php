<div >
		<!--<div class="col-xs-12">
			<h2 class="text-center">Crea tu cuenta</h2>
		</div>
		<br/><br/> -->
		
<!--		<form class="form-horizontal">

			<div class="form-group form-group-md">
				<div class="col-xs-12 col-sm-4">
					<div class="input-group">
						<div class="input-group-addon"><span class="glyphicon glyphicon-user"></span></div>
						<input type="text" class="form-control" name="txtNombre" placeholder="Nombre">
					</div>
				</div>
			</div>
			<div class="form-group form-group-md">
				<div class="col-xs-12 col-sm-4">
					<div class="input-group">
						<div class="input-group-addon"><span class="glyphicon glyphicon-user"></span></div>
						<input type="text" class="form-control" name="txtApellido" placeholder="Apellido">
					</div>
				</div>
			</div>
			<div class="form-group form-group-md">
				<div class="col-xs-12 col-sm-4">
					<div class="input-group">
						<div class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></div>
						<input type="tel" class="form-control" name="txtTelefono" placeholder="Teléfono">
					</div>
				</div>
			</div>
			<div class="form-group form-group-md">
				<div class="col-xs-12 col-sm-4">
					<select class="form-control">
						<option value="">Claro</option>
						<option value="">Movistar</option>
					</select>
				</div>
			</div>
			<div class="form-group form-group-md">
				<div class="col-xs-12 col-sm-4">
					<select class="form-control">
						<option value="">Celular</option>
						<option value="">Convencional</option>
					</select>
				</div>
			</div>
			<div class="form-group form-group-md">
				<div class="col-xs-12 col-sm-4">
					<div class="input-group">
						<div class="input-group-addon"><span>@</span></div>
						<input type="email" class="form-control" name="txtCorreo" placeholder="Correo">
					</div>
				</div>
			</div>
			<div class="form-group form-group-md">
				<div class="col-xs-12 col-sm-4">
					<div class="input-group">
						<div class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></div>
						<input type="password" class="form-control" name="txtPassword" placeholder="Contraseña">
					</div>
				</div>
			</div>
			
		</form>
-->
	<div class="jumbotron">
		<div class="container">
			<h1>Registro gratis</h1>
			<p>Una vez que te registres, podrás empezar a anunciar o promocionar tus articulos a vender, completamente gratis.</p>

		<div class="panel panel-info col-xs-12 col-sm-6">
		<div class="panel-heading text-center"><h4>Crear nueva cuenta</h4></div>
		  <div class="panel-body">
		    <form class="form-horizontal formulario-horizontal">

				<div class="form-group form-group">
					<div class="col-xs-12">
						<div class="input-group">
							<div class="input-group-addon"><span class="glyphicon glyphicon-user"></span></div>
							<input type="text" class="form-control" name="txtNombre" placeholder="Nombre">
						</div>
					</div>
				</div>
				<div class="form-group form-group">
					<div class="col-xs-12">
						<div class="input-group">
							<div class="input-group-addon"><span class="glyphicon glyphicon-user"></span></div>
							<input type="text" class="form-control" name="txtApellido" placeholder="Apellido">
						</div>
					</div>
				</div>
				<div class="form-group form-group">
					<div class="col-xs-12">
						<div class="input-group">
							<div class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></div>
							<input type="tel" class="form-control" name="txtTelefono" placeholder="Teléfono">
						</div>
					</div>
				</div>
				<div class="form-group form-group">
					<div class="col-xs-12">
						<select class="form-control">
							<option value="">Claro</option>
							<option value="">Movistar</option>
						</select>
					</div>
				</div>
				<div class="form-group form-group">
					<div class="col-xs-12">
						<select class="form-control">
							<option value="">Celular</option>
							<option value="">Convencional</option>
						</select>
					</div>
				</div>
				<div class="form-group form-group">
					<div class="col-xs-12">
						<div class="input-group">
							<div class="input-group-addon"><span>@</span></div>
							<input type="email" class="form-control" name="txtCorreo" placeholder="Correo">
						</div>
					</div>
				</div>
				<div class="form-group form-group">
					<div class="col-xs-12">
						<div class="input-group">
							<div class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></div>
							<input type="password" class="form-control" name="txtPassword" placeholder="Contraseña">
						</div>
					</div>
				</div>

				<div class="form-group form-group">
					<div class="col-xs-12">
						<div class="input-group">
							<div class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></div>
							<input type="password" class="form-control" name="txtPasswordConfirmar" placeholder="Confirmar contraseña">
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-4">
						<button type="submit" class="btn btn-success btn-lg">
							<span class="glyphicon glyphicon-floppy-saved"></span>Guardar
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
		</div>
	</div>

	
</div>