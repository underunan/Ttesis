<section class="resultados container">
			<h1>EXPLORA LAS TIENDAS</h1>
			<div class="row">
			<!--
			<article class="col-sm-4">
				<div class="thumbnail">
					<img src="img/smartphone.jpg" alt="smartphone" class="img-responsive">
					<div class="caption">
						<h4>Samsung galaxy</h4>
							<div class="item-descripcion">
								<span class="item-valor">$500</span>
							</div>
							<div>
							<a href="#modal-info" class="btn btn-info" role="button" data-toggle="modal">Detalles</a>
							</div>

					</div>
				</div>

				INICIO DE LA VENTANA EMERGENTE
				<div class="modal fade" id="modal-info" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				  <div class="modal-dialog" role="document">
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				        	<span aria-hidden="true">&times;</span>
				        </button>

				        <!--Titulo de la ventana. Aquí estará el nombre del producto
				        <h4 class="modal-title text-center" id="myModalLabel">Descripción del producto</h4>

				      </div>

				      <!--Aquí estará la información de toda la descripción del producto
				      <div class="modal-body">
				        <div id="map-canvas" style="height:250px; width:100%;"></div>
				        <div class="container-fluid">
				        	<div class="row">
				        		<div class="well col-md-4 col-xs-12">col-md-4</div>
				        		<div class="well col-md-4 col-xs-12">col-md-4</div>
				        		<div class="well col-md-4 col-xs-12">col-md-4</div>
				        	</div>
				        </div>
				      </div>

				      <div class="modal-footer">
				        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				      </div>
				    </div>
				  </div>
				</div>
				<!--FIN DE LA VENTANA EMERGENTE
			</article>
			-->

			<!-- Modificando un article -->
			<article class="col-sm-6 col-md-4">
							<div class="thumbnail">
								<h4><span class="label label-warning pull-left"><span class="icon icon-eye"></span> nuevo</span></h4>
								<img src="img/pantalon.jpg" style="height:auto" alt="zapatos" class="img-responsive">
								<div class="caption bg-danger container-fluid">
										<h4 class="titulo text-center">Deportivos Nike</h4>
										<div class="item-descripcion">
											<span class="item-valor col-sm-6 icon icon-price-tag pull-left">$500</span>
											<div class="item-fecha col-sm-6 badge pull-right">
												<span class="icon icon-history"></span>
												<span>Hace 7 días</span>
											</div>
										</div>
									<a href="resultado_busqueda.ht" class="btn btn-danger btn-lg col-xs-12 col-sm-12" role="button">Ver más</a>
								</div>
							</div>
			</article>
			<!-- FIN DE ARTICLE -->

			<!-- Modificando un article -->
			<article class="col-sm-6 col-md-4">
							<div class="thumbnail">
								<h4><span class="label label-warning pull-left"><span class="icon icon-eye"></span> nuevo</span></h4>
								<img src="img/zapatos.jpg" style="height:auto" alt="zapatos" class="img-responsive">
								<div class="caption bg-danger container-fluid">
										<h4 class="titulo text-center">Deportivos Nike</h4>
										<div class="item-descripcion">
											<span class="item-valor col-sm-6 icon icon-price-tag pull-left">$500</span>
											<div class="item-fecha col-sm-6 badge pull-right">
												<span class="icon icon-history"></span>
												<span>Hace 7 días</span>
											</div>
										</div>
									<a href="resultado_busqueda.ht" class="btn btn-danger btn-lg col-xs-12 col-sm-12" role="button">Ver más</a>
								</div>
							</div>
			</article>
			<!-- FIN DE ARTICLE -->

			<!-- Modificando un article -->
			<article class="col-sm-6 col-md-4">
							<div class="thumbnail">
								<h4><span class="label label-danger pull-left"><span class="icon icon-eye"></span> usado</span></h4>
								<img src="img/lavadora.jpg" style="height:auto" alt="lavadora" class="img-responsive">
								<div class="caption bg-danger container-fluid">
										<h4 class="titulo text-center">Deportivos Nike</h4>
										<div class="item-descripcion">
											<span class="item-valor col-sm-6 icon icon-price-tag pull-left">$500</span>
											<div class="item-fecha col-sm-6 badge pull-right">
												<span class="icon icon-history"></span>
												<span>Hace 7 días</span>
											</div>
										</div>
									<a href="resultado_busqueda.ht" class="btn btn-danger btn-lg col-xs-12 col-sm-12" role="button">Ver más</a>
								</div>
							</div>
			</article>
			<!-- FIN DE ARTICLE -->


			<!-- Modificando un article -->
			<article class="col-sm-6 col-md-4">
							<div class="thumbnail">
								<h4><span class="label label-danger pull-left"><span class="icon icon-eye"></span> usado</span></h4>
								<img src="img/silla_playera.jpg" style="height:auto" alt="silla playera" class="img-responsive">
								<div class="caption bg-danger container-fluid">
										<h4 class="titulo text-center">Deportivos Nike</h4>
										<div class="item-descripcion">
											<span class="item-valor col-sm-6 icon icon-price-tag pull-left">$500</span>
											<div class="item-fecha col-sm-6 badge pull-right">
												<span class="icon icon-history"></span>
												<span>Hace 7 días</span>
											</div>
										</div>
									<a href="resultado_busqueda.ht" class="btn btn-danger btn-lg col-xs-12 col-sm-12" role="button">Ver más</a>
								</div>
							</div>
			</article>
			<!-- FIN DE ARTICLE -->

			<!-- Modificando un article -->
			<article class="col-sm-6 col-md-4">
							<div class="thumbnail">
								<h4><span class="label label-warning pull-left"><span class="icon icon-eye"></span> nuevo</span></h4>
								<img src="img/zapatos.jpg" style="height:auto" alt="zapatos" class="img-responsive">
								<div class="caption bg-danger container-fluid">
										<h4 class="titulo text-center">Deportivos Nike</h4>
										<div class="item-descripcion">
											<span class="item-valor col-sm-6 icon icon-price-tag pull-left">$500</span>
											<div class="item-fecha col-sm-6 badge pull-right">
												<span class="icon icon-history"></span>
												<span>Hace 7 días</span>
											</div>
										</div>
									<a href="resultado_busqueda.ht" class="btn btn-danger btn-lg col-xs-12 col-sm-12" role="button">Ver más</a>
								</div>
							</div>
			</article>
			<!-- FIN DE ARTICLE -->
			</div>
		</section>